import os
from dotenv import load_dotenv
load_dotenv()

from flask import Flask
from waitress import serve
from src.extensions import db, scheduler
from src.routes import register_routes
from src.services.engine import TradingEngine
from src.config import Settings

def create_app() -> Flask:
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.config.from_mapping(
        SECRET_KEY=os.getenv("SECRET_KEY","dev"),
        SQLALCHEMY_DATABASE_URI=os.getenv("DATABASE_URL","sqlite:///trading.db"),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
    )

    db.init_app(app)
    with app.app_context():
        db.create_all()

    # register routes
    register_routes(app)

    # start engine and scheduler job
    engine = TradingEngine(settings=Settings.from_env())
    app.trading_engine = engine

    @app.before_first_request
    def _start_jobs():
        # add/update recurring job
        seconds = int(os.getenv("REFRESH_SECONDS","1"))
        scheduler.add_job(
            id="tick",
            func=engine.tick,
            trigger="interval",
            seconds=seconds,
            replace_existing=True,
            max_instances=1,
            coalesce=True,
        )
        scheduler.init_app(app)
        scheduler.start()

    return app

if __name__ == "__main__":
    app = create_app()
    # Use waitress for production serving
    port = int(os.getenv("PORT","5000"))
    serve(app, host="0.0.0.0", port=port)
