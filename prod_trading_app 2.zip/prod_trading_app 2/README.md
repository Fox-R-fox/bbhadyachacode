# Production-Ready Trading App (Flask + Zerodha + APScheduler)

## Features
- Flask app factory + Waitress server
- SQLAlchemy (SQLite by default)
- 1-second background refresh using APScheduler
- Zerodha wallet & quotes via `kiteconnect` (falls back to paper/mocks when no keys)
- Strategy ensemble: MA crossover (20/50), RSI(14), Supertrend(10,3.0)
- Paper trading engine with basic position/order tracking
- REST endpoints for wallet, ticks, orders, positions, logs
- Minimal responsive dashboard (Pico.css)

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env  # edit values as needed
python app.py
```

To use live Zerodha:
- Set `KITE_API_KEY` and `KITE_ACCESS_TOKEN` in `.env`.
- Set `PAPER_TRADING=false` to place live market orders (market/CNC). **Test carefully.**

## Notes
- The engine runs every `REFRESH_SECONDS` (default 1s).
- When market is closed (India, 09:15–15:30 Mon–Fri), the engine only refreshes quotes/logs and skips trading.
- For production, containerize and mount persistent volume for `trading.db`.
