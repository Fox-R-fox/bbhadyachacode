from flask import Flask, render_template, jsonify, request
from .extensions import db
from .models import Position, Order, Log, Tick
from .config import Settings

def register_routes(app: Flask):
    @app.get("/")
    def dashboard():
        wallet = app.trading_engine.wallet()
        equity = app.trading_engine.equity()
        return render_template("dashboard.html", wallet=wallet, equity=equity)

    @app.get("/api/wallet")
    def api_wallet():
        return jsonify(app.trading_engine.wallet())

    @app.get("/api/metrics")
    def api_metrics():
        return jsonify({
            "equity": app.trading_engine.equity(),
        })

    @app.get("/api/ticks")
    def api_ticks():
        sym = request.args.get("symbol","RELIANCE").upper()
        limit = int(request.args.get("limit","300"))
        from pandas import DataFrame
        df = app.trading_engine.market.get_df(sym, limit)
        return jsonify(df.to_dict(orient="records"))

    @app.get("/api/orders")
    def api_orders():
        rows = Order.query.order_by(Order.created_at.desc()).limit(200).all()
        return jsonify([{
            "id": r.id, "symbol": r.symbol, "side": r.side, "qty": r.quantity, "price": r.price,
            "status": r.status, "is_paper": r.is_paper, "broker_order_id": r.broker_order_id,
            "ts": r.created_at.isoformat()
        } for r in rows])

    @app.get("/api/positions")
    def api_positions():
        rows = Position.query.order_by(Position.opened_at.desc()).all()
        return jsonify([{
            "id": r.id, "symbol": r.symbol, "side": r.side, "qty": r.quantity, "avg_price": r.avg_price,
            "stop_loss": r.stop_loss, "take_profit": r.take_profit, "pnl": r.pnl,
            "opened_at": r.opened_at.isoformat(), "closed_at": r.closed_at.isoformat() if r.closed_at else None
        } for r in rows])

    @app.get("/api/logs")
    def api_logs():
        rows = Log.query.order_by(Log.ts.desc()).limit(200).all()
        return jsonify([{"level": r.level, "message": r.message, "ts": r.ts.isoformat()} for r in rows])

    @app.get("/settings")
    def settings_page():
        return render_template("settings.html", settings=Settings.from_env())

    @app.post("/api/settings/watchlist")
    def set_watchlist():
        data = request.get_json(force=True)
        wl = data.get("watchlist","")
        os_watch = ",".join([s.strip().upper() for s in wl.split(",") if s.strip()])
        return jsonify({"watchlist": os_watch})
