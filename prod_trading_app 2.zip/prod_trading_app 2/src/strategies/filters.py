import pandas as pd
from ta.trend import ADXIndicator

def adx(df: pd.DataFrame, window: int = 14) -> float:
    if df.empty or len(df) < window + 2:
        return 0.0
    ind = ADXIndicator(high=df['high'], low=df['low'], close=df['close'], window=window)
    v = float(ind.adx().iloc[-1])
    return v
