from dataclasses import dataclass
from typing import Optional, Dict, Any
import pandas as pd

@dataclass
class Signal:
    symbol: str
    action: str   # BUY/SELL/HOLD
    reason: str
    strength: float = 0.0

class Strategy:
    name = "Base"
    def generate(self, df: pd.DataFrame, symbol: str) -> Signal:
        raise NotImplementedError
