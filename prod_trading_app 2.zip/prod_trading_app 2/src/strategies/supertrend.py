import pandas as pd
import numpy as np
from .base import Strategy, Signal

class Supertrend(Strategy):
    name = "Supertrend"
    def __init__(self, period:int=10, multiplier:float=3.0):
        self.period=period; self.multiplier=multiplier
    def generate(self, df: pd.DataFrame, symbol:str)->Signal:
        # minimal supertrend
        if len(df) < self.period+2:
            return Signal(symbol,"HOLD","not enough data",0.0)
        hl2 = (df['high'] + df['low'])/2
        tr = (df['high']-df['low']).abs().combine((df['high']-df['close'].shift()).abs(), max).combine((df['low']-df['close'].shift()).abs(), max)
        atr = tr.rolling(self.period).mean()
        upper = hl2 + self.multiplier*atr
        lower = hl2 - self.multiplier*atr
        st = pd.Series(index=df.index, dtype=float)
        dir = pd.Series(index=df.index, dtype=int)
        st.iloc[self.period] = upper.iloc[self.period]
        dir.iloc[self.period] = 1
        for i in range(self.period+1, len(df)):
            cur_upper = min(upper.iloc[i], st.iloc[i-1]) if dir.iloc[i-1]==1 else upper.iloc[i]
            cur_lower = max(lower.iloc[i], st.iloc[i-1]) if dir.iloc[i-1]==-1 else lower.iloc[i]
            if df['close'].iloc[i] > cur_upper:
                dir.iloc[i] = 1
                st.iloc[i] = cur_lower
            elif df['close'].iloc[i] < cur_lower:
                dir.iloc[i] = -1
                st.iloc[i] = cur_upper
            else:
                dir.iloc[i] = dir.iloc[i-1]
                st.iloc[i] = cur_lower if dir.iloc[i]==1 else cur_upper
        if dir.iloc[-2] <= 0 and dir.iloc[-1] > 0:
            return Signal(symbol,"BUY","Supertrend flip up",0.6)
        if dir.iloc[-2] >= 0 and dir.iloc[-1] < 0:
            return Signal(symbol,"SELL","Supertrend flip down",0.6)
        return Signal(symbol,"HOLD","no flip",0.0)
