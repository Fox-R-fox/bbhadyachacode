import pandas as pd
import numpy as np
from .base import Strategy, Signal

class MovingAverageCrossover(Strategy):
    name = "MA Crossover"
    def __init__(self, short:int=20, long:int=50):
        self.short = short
        self.long = long
    def generate(self, df: pd.DataFrame, symbol: str) -> Signal:
        if len(df) < self.long+2:
            return Signal(symbol,"HOLD","not enough data",0.0)
        s = df["close"].rolling(self.short).mean()
        l = df["close"].rolling(self.long).mean()
        if s.iloc[-2] <= l.iloc[-2] and s.iloc[-1] > l.iloc[-1]:
            return Signal(symbol,"BUY",f"{self.short}/{self.long} bull cross",0.7)
        if s.iloc[-2] >= l.iloc[-2] and s.iloc[-1] < l.iloc[-1]:
            return Signal(symbol,"SELL",f"{self.short}/{self.long} bear cross",0.7)
        return Signal(symbol,"HOLD","no cross",0.0)
