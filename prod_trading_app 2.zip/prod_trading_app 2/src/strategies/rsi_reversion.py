import pandas as pd
from ta.momentum import RSIIndicator
from .base import Strategy, Signal

class RSIReversion(Strategy):
    name = "RSI Reversion"
    def __init__(self, period:int=14, low:float=30, high:float=70):
        self.period=period; self.low=low; self.high=high
    def generate(self, df: pd.DataFrame, symbol:str)->Signal:
        if len(df) < self.period+1:
            return Signal(symbol,"HOLD","not enough data",0.0)
        r = RSIIndicator(df['close'], window=self.period).rsi()
        rv = r.iloc[-1]
        if rv < self.low:
            return Signal(symbol,"BUY",f"RSI {rv:.1f} < {self.low}",0.6)
        if rv > self.high:
            return Signal(symbol,"SELL",f"RSI {rv:.1f} > {self.high}",0.6)
        return Signal(symbol,"HOLD","RSI neutral",0.0)
