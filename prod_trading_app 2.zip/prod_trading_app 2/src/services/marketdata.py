from __future__ import annotations
from collections import deque, defaultdict
from typing import Dict, Deque, List
import pandas as pd
from datetime import datetime
from .zerodha_client import ZerodhaClient

class MarketData:
    def __init__(self, client: ZerodhaClient, maxlen:int=4000):
        self.client = client
        self.buffers: Dict[str, Deque[dict]] = defaultdict(lambda: deque(maxlen=maxlen))

    def push_quote(self, symbol:str, ltp:float, ts:datetime|None=None):
        if ts is None: ts = datetime.utcnow()
        self.buffers[symbol].append({"ts": ts, "close": ltp, "high": ltp, "low": ltp, "open": ltp})

    def get_df(self, symbol:str, window:int=300) -> pd.DataFrame:
        data = list(self.buffers[symbol])[-window:]
        if not data:
            return pd.DataFrame(columns=["ts","open","high","low","close"])
        return pd.DataFrame(data)

    def refresh_quotes(self, symbols: List[str]):
        q = self.client.quotes(symbols)
        for s, v in q.items():
            self.push_quote(s, float(v["last_price"]))
        return q
