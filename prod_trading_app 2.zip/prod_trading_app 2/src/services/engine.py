from __future__ import annotations
import math
from typing import List
from datetime import datetime, time as dtime
import pandas as pd

from ..extensions import db
from ..models import Position, Order, Tick, log
from ..config import Settings
from .zerodha_client import ZerodhaClient
from .marketdata import MarketData
from ..strategies.ma_crossover import MovingAverageCrossover
from ..strategies.rsi_reversion import RSIReversion
from ..strategies.supertrend import Supertrend
from ..strategies.filters import adx
from .risk import RiskConfig, compute_atr, position_sizing, stops_targets

def is_market_open(now: datetime|None=None) -> bool:
    now = now or datetime.now()
    if now.weekday()>=5:  # Sat/Sun
        return False
    start = dtime(9,15)
    end = dtime(15,30)
    return start <= now.time() <= end

class TradingEngine:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = ZerodhaClient(settings.kite_api_key, settings.kite_access_token)
        self.market = MarketData(self.client)
        self.strategies = [
            MovingAverageCrossover(20,50),
            RSIReversion(14, 30, 70),
            Supertrend(10,3.0),
        ]
        self.risk_cfg = RiskConfig(risk_per_trade=0.01, atr_period=14, atr_multiple=2.0, reward_multiple=2.0)
        # Risk guardrails
        self.max_daily_loss_pct = 0.03   # 3% of starting day equity
        self.max_open_positions = 5
        self.day_start_equity = None
        log("INFO", f"Engine init paper_trading={settings.paper_trading} watchlist={settings.watchlist}")

    def equity(self) -> float:
        # Equity = wallet available + market value of open positions (paper approximation)
        w = self.wallet().get("available", 0.0) or 0.0
        open_positions = Position.query.filter_by(closed_at=None).all()
        mtm = 0.0
        for p in open_positions:
            price = self.market.get_df(p.symbol, 1)['close'].iloc[-1] if len(self.market.get_df(p.symbol, 1)) else p.avg_price
            if p.side == "BUY":
                mtm += (price - p.avg_price) * p.quantity
            else:
                mtm += (p.avg_price - price) * p.quantity
        return float(w + mtm)

    def evaluate(self, symbol:str, df: pd.DataFrame):
        votes = []
        for strat in self.strategies:
            sig = strat.generate(df, symbol)
            votes.append(sig)
        # Simple ensemble: BUY if >=2 BUY, SELL if >=2 SELL, else HOLD
        buys = sum(1 for s in votes if s.action=="BUY")
        sells = sum(1 for s in votes if s.action=="SELL")
        if buys >= 2: return "BUY", ", ".join([s.reason for s in votes if s.action=="BUY"])
        if sells >= 2: return "SELL", ", ".join([s.reason for s in votes if s.action=="SELL"])
        return "HOLD", " | ".join([s.reason for s in votes])

    def place(self, symbol:str, side:str, qty:int, price:float|None=None, sl:float|None=None, tp:float|None=None):
        if self.settings.paper_trading:
            ord = Order(symbol=symbol, side=side, quantity=qty, price=price, status="FILLED", is_paper=True)
            db.session.add(ord)
            # update positions (netting; cash market long-only for simplicity)
            pos = Position.query.filter_by(symbol=symbol, closed_at=None).first()
            if side=="BUY":
                if pos and pos.side=="BUY":
                    new_qty = pos.quantity + qty
                    pos.avg_price = ((pos.avg_price*pos.quantity) + (price or 0.0)*qty)/max(new_qty,1)
                    pos.quantity = new_qty
                    pos.stop_loss = sl or pos.stop_loss
                    pos.take_profit = tp or pos.take_profit
                else:
                    db.session.add(Position(symbol=symbol, quantity=qty, avg_price=price or 0.0, side="BUY", stop_loss=sl, take_profit=tp))
            else:
                if pos and pos.side=="BUY":
                    # close position
                    pnl = (price - pos.avg_price) * pos.quantity
                    pos.pnl = pnl
                    pos.closed_at = datetime.utcnow()
            db.session.commit()
            return {"status":"paper","order_id": ord.id}
        else:
            resp = self.client.place_order(symbol, side, qty)
            ord = Order(symbol=symbol, side=side, quantity=qty, price=price, status="NEW", is_paper=False, broker_order_id=str(resp.get("order_id")))
            db.session.add(ord); db.session.commit()
            return resp

    def wallet(self):
        return self.client.wallet()

    def _apply_stops_targets(self, quotes: dict):
        # Check open positions for SL/TP triggers (paper mode)
        if not self.settings.paper_trading:
            return
        open_positions = Position.query.filter_by(closed_at=None).all()
        for p in open_positions:
            ltp = float(quotes[p.symbol]['last_price']) if p.symbol in quotes else p.avg_price
            hit_sl = p.stop_loss is not None and ((p.side=="BUY" and ltp <= p.stop_loss) or (p.side=="SELL" and ltp >= p.stop_loss))
            hit_tp = p.take_profit is not None and ((p.side=="BUY" and ltp >= p.take_profit) or (p.side=="SELL" and ltp <= p.take_profit))
            if hit_sl or hit_tp:
                self.place(p.symbol, "SELL" if p.side=="BUY" else "BUY", p.quantity, ltp)
                log("INFO", f"Exit {p.symbol} on {'SL' if hit_sl else 'TP'} @ {ltp}")

    def _daily_guards(self):
        # initialize day start equity
        if self.day_start_equity is None:
            self.day_start_equity = self.equity()
        max_loss = self.day_start_equity * self.max_daily_loss_pct
        dd = max(0.0, self.day_start_equity - self.equity())
        if dd >= max_loss:
            return False, f"Daily loss {dd:.2f} exceeds max {max_loss:.2f}"
        # max open positions
        open_count = Position.query.filter_by(closed_at=None).count()
        if open_count >= self.max_open_positions:
            return False, f"Open positions {open_count} >= limit {self.max_open_positions}"
        return True, ""

    def tick(self):
        # fetch quotes
        quotes = self.market.refresh_quotes(self.settings.watchlist)
        # persist ticks
        for s,v in quotes.items():
            db.session.add(Tick(symbol=s, ltp=float(v['last_price'])))
        db.session.commit()

        # SL/TP enforcement
        self._apply_stops_targets(quotes)

        if not is_market_open():
            log("INFO","Market closed; skipping trade eval")
            return

        ok, reason = self._daily_guards()
        if not ok:
            log("INFO", f"Risk guard: {reason}")
            return

        # per symbol evaluation
        equity_now = self.equity() or 100000.0
        for s in self.settings.watchlist:
            df = self.market.get_df(s, window=600)
            if len(df) < 60:
                continue
            # regime filter via ADX
            adx_val = adx(df, 14)
            action, reason = self.evaluate(s, df)
            price = float(quotes[s]['last_price'])

            # Risk and sizing
            atr = compute_atr(df, period=14)
            qty = position_sizing(equity=equity_now, price=price, atr=atr, cfg=self.risk_cfg)
            sl, tp = stops_targets(price, "BUY", atr, self.risk_cfg)

            # Trade logic (cash long-only; require ADX>18 for trend signals; otherwise prefer RSI buys)
            should_buy = action=="BUY" and adx_val >= 18 and qty>0
            if should_buy:
                self.place(s, "BUY", qty, price, sl=sl, tp=tp)
                log("INFO", f"BUY {s} x{qty} @ {price} | {reason} | ADX={adx_val:.1f} ATR={atr:.2f} SL={sl:.2f} TP={tp:.2f}")
            elif action=="SELL":
                # Only sell if we hold long
                pos = Position.query.filter_by(symbol=s, closed_at=None, side="BUY").first()
                if pos:
                    self.place(s, "SELL", pos.quantity, price)
                    log("INFO", f"SELL {s} x{pos.quantity} @ {price} | {reason}")
