from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple
import pandas as pd

@dataclass
class RiskConfig:
    risk_per_trade: float = 0.01      # 1% of equity
    atr_period: int = 14
    atr_multiple: float = 2.0         # SL distance in ATRs
    reward_multiple: float = 2.0      # TP = reward_multiple * risk

def compute_atr(df: pd.DataFrame, period: int) -> float:
    if df.empty or len(df) < period + 2:
        return 0.0
    high, low, close = df['high'], df['low'], df['close']
    prev_close = close.shift(1)
    tr = (high - low).abs().combine((high - prev_close).abs(), max).combine((low - prev_close).abs(), max)
    atr = tr.rolling(period).mean()
    v = float(atr.iloc[-1]) if not atr.empty else 0.0
    return max(v, 0.0)

def position_sizing(equity: float, price: float, atr: float, cfg: RiskConfig) -> int:
    if price <= 0 or atr <= 0:
        return 0
    capital_at_risk = equity * cfg.risk_per_trade
    risk_per_share = cfg.atr_multiple * atr
    qty = int(capital_at_risk // max(risk_per_share, 1e-6))
    return max(qty, 0)

def stops_targets(entry: float, side: str, atr: float, cfg: RiskConfig) -> Tuple[float, float]:
    if atr <= 0:
        return 0.0, 0.0
    risk = cfg.atr_multiple * atr
    if side.upper() == "BUY":
        sl = entry - risk
        tp = entry + cfg.reward_multiple * risk
    else:
        sl = entry + risk
        tp = entry - cfg.reward_multiple * risk
    return float(sl), float(tp)
