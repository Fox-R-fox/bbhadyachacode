from __future__ import annotations
import os
from kiteconnect import KiteConnect
from typing import List, Dict, Any

class ZerodhaClient:
    def __init__(self, api_key: str|None, access_token: str|None):
        self.api_key = api_key
        self.access_token = access_token
        self.kite: KiteConnect|None = None
        if api_key and access_token:
            self.kite = KiteConnect(api_key=api_key)
            self.kite.set_access_token(access_token)

    def is_configured(self) -> bool:
        return self.kite is not None

    # Wallet / margins
    def wallet(self) -> Dict[str, Any]:
        if not self.kite:
            return {"available": 0.0, "utilised": 0.0, "net": 0.0}
        m = self.kite.margins("equity")
        available = m.get("net", 0.0)
        utilised = m.get("utilised", {}).get("debits", 0.0) if isinstance(m.get("utilised"), dict) else 0.0
        return {"available": available, "utilised": utilised, "net": available - utilised}

    # Quotes
    def quotes(self, symbols: List[str]) -> Dict[str, Any]:
        if not self.kite:
            # Return mock quotes when not configured
            import random
            return {s: {"last_price": round(100 + random.random()*50,2)} for s in symbols}
        # NSE symbols should be passed as "NSE:RELIANCE"
        fulls = [f"NSE:{s}" for s in symbols]
        q = self.kite.quote(fulls)
        # normalize
        out = {}
        for k,v in q.items():
            sym = k.split(":")[-1]
            out[sym] = {"last_price": v.get("last_price")}
        return out

    # Place market order
    def place_order(self, symbol: str, side: str, qty: int) -> Dict[str, Any]:
        if not self.kite:
            return {"status":"paper", "order_id": f"PAPER-{symbol}-{side}-{qty}"}
        tx = self.kite.TRANSACTION_TYPE_BUY if side.upper()=="BUY" else self.kite.TRANSACTION_TYPE_SELL
        variety = self.kite.VARIETY_REGULAR
        product = self.kite.PRODUCT_CNC
        order_type = self.kite.ORDER_TYPE_MARKET
        resp = self.kite.place_order(
            variety=variety,
            exchange=self.kite.EXCHANGE_NSE,
            tradingsymbol=symbol,
            transaction_type=tx,
            quantity=qty,
            product=product,
            order_type=order_type,
        )
        return {"status":"ok","order_id": resp.get("order_id")}
