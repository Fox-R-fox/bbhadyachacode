import os
from dataclasses import dataclass

def as_bool(v:str, default=False):
    if v is None: return default
    return v.lower() in ("1","true","yes","y","on")

@dataclass
class Settings:
    paper_trading: bool = True
    refresh_seconds: int = 1
    watchlist: list[str] = None  # list of NSE symbols like TCS, RELIANCE, INFY
    kite_api_key: str = None
    kite_access_token: str = None
    kite_public_token: str = None

    @staticmethod
    def from_env() -> "Settings":
        wl = os.getenv("WATCHLIST","RELIANCE,INFY,TCS,HDFCBANK,ITC").split(",")
        return Settings(
            paper_trading=as_bool(os.getenv("PAPER_TRADING","true"), True),
            refresh_seconds=int(os.getenv("REFRESH_SECONDS","1")),
            watchlist=[s.strip().upper() for s in wl if s.strip()],
            kite_api_key=os.getenv("KITE_API_KEY"),
            kite_access_token=os.getenv("KITE_ACCESS_TOKEN"),
            kite_public_token=os.getenv("KITE_PUBLIC_TOKEN"),
        )
