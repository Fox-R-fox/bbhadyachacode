from datetime import datetime
from .extensions import db

class Setting(db.Model):
    __tablename__ = "settings"
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False)
    value = db.Column(db.String(512), nullable=True)

class Position(db.Model):
    __tablename__ = "positions"
    id = db.Column(db.Integer, primary_key=True)
    symbol = db.Column(db.String(32), index=True, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    avg_price = db.Column(db.Float, nullable=False)
    side = db.Column(db.String(4), nullable=False)  # BUY / SELL
    stop_loss = db.Column(db.Float, nullable=True)
    take_profit = db.Column(db.Float, nullable=True)
    opened_at = db.Column(db.DateTime, default=datetime.utcnow)
    closed_at = db.Column(db.DateTime, nullable=True)
    pnl = db.Column(db.Float, default=0.0)

class Order(db.Model):
    __tablename__ = "orders"
    id = db.Column(db.Integer, primary_key=True)
    symbol = db.Column(db.String(32), index=True, nullable=False)
    side = db.Column(db.String(4), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=True)
    status = db.Column(db.String(16), default="NEW")  # NEW/FILLED/CANCELLED/REJECTED
    is_paper = db.Column(db.Boolean, default=True)
    broker_order_id = db.Column(db.String(64), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Tick(db.Model):
    __tablename__ = "ticks"
    id = db.Column(db.Integer, primary_key=True)
    symbol = db.Column(db.String(32), index=True, nullable=False)
    ltp = db.Column(db.Float, nullable=False)
    ts = db.Column(db.DateTime, default=datetime.utcnow, index=True)

class Log(db.Model):
    __tablename__ = "logs"
    id = db.Column(db.Integer, primary_key=True)
    level = db.Column(db.String(8), default="INFO")
    message = db.Column(db.String(1024), nullable=False)
    ts = db.Column(db.DateTime, default=datetime.utcnow, index=True)

def log(level:str, message:str):
    from .extensions import db
    db.session.add(Log(level=level, message=message))
    db.session.commit()
