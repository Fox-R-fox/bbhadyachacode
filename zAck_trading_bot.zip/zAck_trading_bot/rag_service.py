import logging
import pandas as pd
import os

class RAGService:
    """
    A placeholder for the Retrieval-Augmented Generation service.
    This service is designed to load historical trade data and generate
    contextual insights to aid the AI's decision-making process.
    """
    def __init__(self, config: dict):
        self.config = config
        # FIX: Corrected the config key from 'enable_rag' to 'use_rag' to match config.yaml
        self.enabled = self.config['trading_flags'].get('use_rag', False)
        self.trade_log_path = 'output/trade_log.xlsx'
        self.min_trading_days = self.config['trading_flags'].get('rag_min_trading_days', 5)

    def _load_data(self) -> pd.DataFrame | None:
        """Loads the historical trade log from the Excel file."""
        if not self.enabled:
            return None
        
        if not os.path.exists(self.trade_log_path):
            logging.warning("[RAG Service] Trade log file not found. Cannot generate context.")
            return None
            
        try:
            df = pd.read_excel(self.trade_log_path)
            # Check for sufficient historical data
            if 'Timestamp' in df.columns:
                df['Timestamp'] = pd.to_datetime(df['Timestamp'])
                trading_days = df['Timestamp'].dt.date.nunique()
                if trading_days < self.min_trading_days:
                    logging.warning(f"[RAG Service] Insufficient historical data. Found {trading_days} days, need {self.min_trading_days}.")
                    return None
            return df
        except Exception as e:
            logging.error(f"[RAG Service] Error loading trade log for RAG: {e}")
            return None

    def retrieve_context_for_strategy_selection(self) -> str | None:
        """
        Generates a summary from historical data to help the LLM select a strategy.
        This is a placeholder for your custom RAG logic.
        """
        df = self._load_data()
        if df is None or df.empty:
            return None

        # --- Placeholder RAG Logic ---
        # This is where you would implement your sophisticated analysis.
        # For now, we'll provide a simple summary of recent performance.
        
        recent_trades = df.tail(10)
        recent_pnl = recent_trades['ProfitLoss'].sum()
        win_rate = (recent_trades['ProfitLoss'] > 0).sum() / len(recent_trades) * 100 if not recent_trades.empty else 0

        # Create a simple, actionable insight for the LLM
        summary = (
            f"Recent Performance Summary (last {len(recent_trades)} trades):\n"
            f"- Net P/L: {recent_pnl:,.2f}\n"
            f"- Win Rate: {win_rate:.2f}%\n"
            f"Observation: If recent performance is poor, consider less aggressive or counter-trend strategies. "
            f"If performance is strong, favor trend-following strategies."
        )
        
        logging.info("[RAG Service] Generated historical context for strategy selection.")
        return summary
        
    def retrieve_context_for_loss_analysis(self, losing_trade_details: dict) -> str | None:
        """
        Retrieves context specifically for analyzing a losing trade.
        This is another placeholder for your custom RAG logic.
        """
        df = self._load_data()
        if df is None or df.empty:
            return None
        
        # --- Placeholder RAG Logic ---
        # Find similar historical trades to provide context on the current loss.
        strategy_used = losing_trade_details.get('Strategy')
        similar_trades = df[df['Strategy'] == strategy_used]
        
        if similar_trades.empty:
            return "No similar historical trades found for this strategy."

        similar_win_rate = (similar_trades['ProfitLoss'] > 0).sum() / len(similar_trades) * 100
        
        summary = (
            f"Historical Context for the '{strategy_used}' strategy:\n"
            f"- This strategy has been used {len(similar_trades)} times historically.\n"
            f"- Its historical win rate is {similar_win_rate:.2f}%.\n"
            f"Analysis Hint: Compare today's market conditions to the conditions on days when this strategy previously failed."
        )

        logging.info(f"[RAG Service] Generated context for loss analysis of '{strategy_used}'.")
        return summary