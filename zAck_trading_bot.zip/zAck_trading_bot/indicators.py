import pandas as pd
import numpy as np
import talib

def calculate_cpr(df_prev_day):
    """Calculates Central Pivot Range (CPR) and standard pivots."""
    if df_prev_day.empty:
        return {}
    high = df_prev_day['high'].iloc[-1]
    low = df_prev_day['low'].iloc[-1]
    close = df_prev_day['close'].iloc[-1]

    pivot = (high + low + close) / 3
    bc = (high + low) / 2
    tc = (pivot - bc) + pivot

    r1 = (2 * pivot) - low
    s1 = (2 * pivot) - high
    r2 = pivot + (high - low)
    s2 = pivot - (high - low)
    r3 = high + 2 * (pivot - low)
    s3 = low - 2 * (high - pivot)

    pivots = {'pivot': pivot, 'bc': bc, 'tc': tc, 'r1': r1, 'r2': r2, 'r3': r3, 's1': s1, 's2': s2, 's3': s3}
    if pivots['tc'] < pivots['bc']:
        pivots['tc'], pivots['bc'] = pivots['bc'], pivots['tc']
    
    # Add previous day high/low for breakout strategies
    pivots['prev_high'] = high
    pivots['prev_low'] = low
    return pivots

def calculate_ema(prices, period):
    """Calculates the Exponential Moving Average (EMA)."""
    return talib.EMA(prices, timeperiod=period)

def calculate_rsi(prices, period=14):
    """Calculates the Relative Strength Index (RSI)."""
    return talib.RSI(prices, timeperiod=period)

def check_ema_crossover(df, current_candle_idx, period):
    """Checks for a bullish or bearish EMA crossover."""
    if current_candle_idx < 1:
        return "None"
    
    current_candle = df.iloc[current_candle_idx]
    last_candle = df.iloc[current_candle_idx - 1]
    
    ema_col = f'ema_{period}'
    price = current_candle['close']
    last_price = last_candle['close']
    ema_val = current_candle[ema_col]
    last_ema_val = last_candle[ema_col]
    
    # Bullish Crossover: Price crossed from below to above EMA
    if last_price <= last_ema_val and price > ema_val:
        return "Bullish"
    # Bearish Crossover: Price crossed from above to below EMA
    if last_price >= last_ema_val and price < ema_val:
        return "Bearish"
    
    return "None"

def check_rsi_divergence(price_df, rsi_series, lookback=30):
    """Simplified check for bullish/bearish RSI divergence."""
    if len(price_df) < lookback or len(rsi_series) < lookback:
        return "None"
        
    price_slice = price_df.tail(lookback)
    rsi_slice = rsi_series.tail(lookback)

    if rsi_slice.empty or len(rsi_slice) < 2: return "None"

    # Bullish Divergence: Lower low in price, higher low in RSI
    if price_slice['low'].iloc[-1] < price_slice['low'].iloc[:-1].min() and rsi_slice.iloc[-1] > rsi_slice.iloc[:-1].min():
        return "Bullish"
    # Bearish Divergence: Higher high in price, lower high in RSI
    if price_slice['high'].iloc[-1] > price_slice['high'].iloc[:-1].max() and rsi_slice.iloc[-1] < rsi_slice.iloc[:-1].max():
        return "Bearish"
        
    return "None"

def check_cpr_breakout(current_candle, cpr_pivots, last_candle):
    """Checks for a bullish or bearish breakout from the CPR."""
    if not cpr_pivots: return "None"
    price = current_candle['close']
    last_price = last_candle['close']
    tc = cpr_pivots.get('tc', float('inf'))
    bc = cpr_pivots.get('bc', float('-inf'))

    if last_price < tc and price > tc: return "Bullish"
    if last_price > bc and price < bc: return "Bearish"
    return "None"

def _find_extrema(series: pd.Series, window: int = 5):
    """A simplified helper to find local peaks and troughs."""
    local_max = series.rolling(window=window, center=True).max()
    local_min = series.rolling(window=window, center=True).min()
    peaks = series[series == local_max].index
    troughs = series[series == local_min].index
    return peaks, troughs

def check_momentum_divergence(price_series: pd.Series, oscillator_series: pd.Series, lookback: int = 45):
    """
    Checks for Class A Regular Divergence over the lookback period.
    Returns 'Bullish', 'Bearish', or 'None'.
    """
    if len(price_series) < lookback or len(oscillator_series) < lookback:
        return "None"
        
    price_slice = price_series.tail(lookback)
    osc_slice = oscillator_series.tail(lookback)

    price_peaks, price_troughs = _find_extrema(price_slice)
    osc_peaks, osc_troughs = _find_extrema(osc_slice)

    # Bearish Divergence: Higher high in price, lower high in oscillator
    if len(price_peaks) >= 2 and len(osc_peaks) >= 2:
        if price_slice[price_peaks[-1]] > price_slice[price_peaks[-2]] and osc_slice[osc_peaks[-1]] < osc_slice[osc_peaks[-2]]:
            return "Bearish"

    # Bullish Divergence: Lower low in price, higher low in oscillator
    if len(price_troughs) >= 2 and len(osc_troughs) >= 2:
        if price_slice[price_troughs[-1]] < price_slice[price_troughs[-2]] and osc_slice[osc_troughs[-1]] > osc_slice[osc_troughs[-2]]:
            return "Bullish"

    return "None"

def is_trend_overextended(day_df: pd.DataFrame, lookback: int = 20, percent_move: float = 0.01, rsi_high: int = 70, rsi_low: int = 30):
    """Quantitatively defines an overextended trend."""
    if len(day_df) < lookback:
        return "None"
    price_slice = day_df['close'][-lookback:]
    max_price, min_price = price_slice.max(), price_slice.min()
    current_price = price_slice.iloc[-1]
    rsi = day_df['rsi'].iloc[-1]
    
    # Check for overextended uptrend
    if (current_price / min_price - 1) > percent_move and rsi > rsi_high:
        return "Uptrend"
    # Check for overextended downtrend
    if (max_price / current_price - 1) > percent_move and rsi < rsi_low:
        return "Downtrend"
        
    return "None"

# FIX: Removed the stray '}' character that was here and caused a SyntaxError.