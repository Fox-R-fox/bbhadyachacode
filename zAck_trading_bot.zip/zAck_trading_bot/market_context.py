import logging
import datetime
import requests
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
import time
from kiteconnect.exceptions import DataException, NetworkException

class EconomicCalendar:
    """
    Dynamically scrapes and provides dates for major market-moving events.
    It fetches data from the official Federal Reserve and uses a reliable fallback for RBI.
    """
    def __init__(self):
        self.events = self._load_events()

    def _scrape_fed_dates(self):
        """Scrapes FOMC meeting dates from the Federal Reserve website with improved resilience."""
        fed_dates = {}
        try:
            url = "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"
            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()

            soup = BeautifulSoup(response.content, 'html.parser')
            # More specific selector to target meeting panels
            panels = soup.select('div.panel.fomc-meeting')

            for panel in panels:
                year_tag = panel.find('h4', class_='panel-heading')
                if not year_tag or not year_tag.text: continue

                year_str_list = [s for s in year_tag.text.split() if s.isdigit()]
                if not year_str_list: continue
                year = year_str_list[0]

                meeting_entries = panel.select('div.row.fomc-meeting__month')
                for entry in meeting_entries:
                    month_tag = entry.find('div', class_='fomc-meeting__month-name')
                    # The final day of the meeting is usually the most important one
                    date_tag = entry.select_one('div.fomc-meeting__date:last-child')

                    if month_tag and date_tag:
                        try:
                            month = month_tag.text.strip()
                            day = date_tag.text.strip().split('-')[-1].strip() # Handle date ranges like "30-31"
                            date_str = f"{day} {month} {year}"
                            event_date = datetime.datetime.strptime(date_str, "%d %B %Y").date()
                            fed_dates[event_date.strftime('%Y-%m-%d')] = "EVENT_FED_MEETING"
                        except (ValueError, IndexError):
                            logging.warning(f"Could not parse a date entry: month='{month_tag.text}', year='{year}'")
                            continue
            if fed_dates:
                logging.info(f"Successfully scraped {len(fed_dates)} FED meeting dates.")
            else:
                logging.warning("Scraping FED dates returned no results. Website structure may have changed.")
        except requests.RequestException as e:
            logging.error(f"Could not scrape FED dates due to a network error: {e}. Using hardcoded fallbacks.")
            # Fallback dates in case of scraping failure
            fed_dates["2025-12-17"] = "EVENT_FED_MEETING"
            fed_dates["2026-01-28"] = "EVENT_FED_MEETING"
        except Exception as e:
            logging.error(f"An unexpected error occurred during FED date scraping: {e}", exc_info=True)
        return fed_dates

    def _get_rbi_dates(self):
        """Uses a static list for RBI dates as scraping is unreliable. Keep this updated manually."""
        logging.info("Loading static RBI policy dates. Please update this list periodically.")
        # NOTE: These are forward-looking dates.
        rbi_dates = {
            "2025-12-05": "EVENT_RBI_POLICY",
            "2026-02-06": "EVENT_RBI_POLICY",
            "2026-04-08": "EVENT_RBI_POLICY",
            "2026-06-05": "EVENT_RBI_POLICY",
        }
        return rbi_dates

    def _load_events(self):
        """Loads events from all sources."""
        logging.info("EconomicCalendar: Loading dynamic event dates...")
        fed = self._scrape_fed_dates()
        rbi = self._get_rbi_dates()
        return {**fed, **rbi}

    def get_event_for_date(self, date: datetime.date) -> str | None:
        """Returns the event for a given date, if any."""
        return self.events.get(date.strftime('%Y-%m-%d'))


class MarketConditionIdentifier:
    """Identifies the market conditions for a given date using multiple factors."""
    def __init__(self, kite, config):
        self.kite = kite
        self.config = config
        self.calendar = EconomicCalendar()
        # Initialize tokens once to avoid repeated API calls for instrument lists
        self.vix_token = self._get_instrument_token('INDIA VIX', 'NSE')
        self.nifty_token = self._get_instrument_token(config['trading_flags']['underlying_instrument'], 'NSE')

    def _get_instrument_token(self, name, exchange):
        """Helper to find instrument token with a retry mechanism."""
        for attempt in range(3):
            try:
                instruments = self.kite.instruments(exchange)
                return [i['instrument_token'] for i in instruments if i.get('tradingsymbol') == name][0]
            except (DataException, NetworkException, IndexError) as e:
                logging.warning(f"Attempt {attempt + 1}/3: Failed to fetch instrument token for '{name}'. Retrying... Error: {e}")
                time.sleep(2 * (attempt + 1))
        raise ConnectionError(f"Could not fetch instrument token for '{name}' after multiple retries.")

    def get_conditions_for_date(self, target_date: datetime.date) -> set:
        """Fetches all relevant data for a target date and returns a set of condition tags."""
        from_date = target_date - datetime.timedelta(days=90) # Fetch more data for better rolling averages
        conditions = set()

        try:
            # 1. Get VIX condition from historical data
            vix_hist_data = self.kite.historical_data(self.vix_token, from_date, target_date, "day")
            if not vix_hist_data:
                logging.warning("Could not fetch VIX historical data.")
            else:
                vix_df = pd.DataFrame(vix_hist_data)
                vix_df['date'] = pd.to_datetime(vix_df['date']).dt.date
                today_vix_data = vix_df[vix_df['date'] == target_date]

                if not today_vix_data.empty:
                    vix_value = today_vix_data.iloc[-1]['close']
                    if vix_value < 17: conditions.add('VIX_LOW')
                    elif 17 <= vix_value < 25: conditions.add('VIX_MEDIUM')
                    else: conditions.add('VIX_HIGH')

            # 2. Get Event condition
            if event := self.calendar.get_event_for_date(target_date):
                conditions.add(event)

            # 3. Get Implied Volatility (IV) proxy condition
            nifty_hist_data = self.kite.historical_data(self.nifty_token, from_date, target_date, "day")
            if not nifty_hist_data:
                logging.warning("Could not fetch NIFTY historical data for IV proxy.")
            else:
                nifty_df = pd.DataFrame(nifty_hist_data)
                nifty_df['returns'] = np.log(nifty_df['close'] / nifty_df['close'].shift(1)) # Use log returns
                # Compare recent volatility to a longer-term average
                recent_vol = nifty_df['returns'].rolling(window=7).std().iloc[-1]
                long_term_vol = nifty_df['returns'].rolling(window=30).std().iloc[-1]

                if not np.isnan(recent_vol) and not np.isnan(long_term_vol):
                    if recent_vol > long_term_vol * 1.25: conditions.add('IV_HIGH')
                    else: conditions.add('IV_LOW')

            return conditions if conditions else {'NORMAL'}
        except Exception as e:
            logging.error(f"Could not determine full market conditions for {target_date}: {e}", exc_info=True)
            return {'UNKNOWN'}