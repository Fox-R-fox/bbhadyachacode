import pandas_ta as ta
import pandas as pd
import logging

def calculate_all_indicators(df: pd.DataFrame, config: dict) -> pd.DataFrame:
    """
    Calculates and attaches all required technical indicators to the dataframe.
    This function is designed to be idempotent and safe to call on new data.
    """
    # Ensure the DataFrame has a DatetimeIndex, which is required by some indicators like VWAP.
    if not isinstance(df.index, pd.DatetimeIndex):
        # Convert 'date' column to datetime and set as index.
        # This handles cases where the index might be reset.
        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])
            df = df.set_index('date').sort_index()
        else:
            logging.error("[Indicator Calculator] DataFrame has no 'date' column or DatetimeIndex.")
            return df # Return original df to avoid crashing

    # Use the pandas_ta extension for a clean and efficient syntax
    df.ta.rsi(length=14, append=True)
    df.ta.ema(length=9, append=True)
    df.ta.ema(length=15, append=True)
    df.ta.ema(length=20, append=True)
    df.ta.ema(length=21, append=True)
    df.ta.ema(length=50, append=True)
    df.ta.supertrend(length=10, multiplier=3, append=True)
    df.ta.macd(fast=12, slow=26, signal=9, append=True)
    df.ta.atr(length=14, append=True)
    df.ta.bbands(length=20, std=2, append=True)
    
    # VWAP requires a DatetimeIndex, which we've already ensured.
    df.ta.vwap(append=True)

    # Calculate rolling means for specific indicators
    if 'ATRr_14' in df.columns:
        df['atr_ma'] = df['ATRr_14'].rolling(window=20).mean()
    if 'VOL' in df.columns: # pandas-ta might create 'VOL' instead of 'volume'
        df['volume_ma'] = df['volume'].rolling(window=20).mean()
    if 'BBB_20_2.0' in df.columns:
        df['bb_bandwidth_ma'] = df['BBB_20_2.0'].rolling(window=20).mean()

    # Calculate spread
    df['spread'] = df['high'] - df['low']
    
    # Clean up any NaNs produced by indicators at the start of the series
    df.bfill(inplace=True) # Back-fill to preserve early data points where possible
    df.fillna(0, inplace=True) # Fill any remaining NaNs with 0
    
    return df