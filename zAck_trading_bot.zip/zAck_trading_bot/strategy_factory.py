import logging
import pandas as pd
import datetime
from indicators import (
    calculate_cpr, check_rsi_divergence, check_cpr_breakout,
    check_momentum_divergence, is_trend_overextended
)

class BaseStrategy:
    """Base class for all trading strategies."""
    def __init__(self, kite, config):
        self.kite = kite
        self.config = config
        self.name = "Base"
        # If True, the strategy can generate signals against the day's primary sentiment.
        self.is_reversal_trade = False

    def generate_signals(self, day_df: pd.DataFrame, sentiment: str, **kwargs) -> str:
        """
        Generates 'BUY', 'SELL', or 'HOLD' signals based on the latest candle.
        The dataframe provided is expected to have all indicators pre-calculated.
        """
        raise NotImplementedError

    def get_status_message(self, day_df: pd.DataFrame, sentiment: str, **kwargs) -> str:
        """Returns a human-readable status message for the current market state."""
        return f"Awaiting signal for {self.name}..."

class Gemini_Default_Strategy(BaseStrategy):
    """A balanced strategy based on CPR breakout, confirmed by EMA and RSI."""
    def __init__(self, kite, config):
        super().__init__(kite, config)
        self.name = "Gemini_Default"

    def generate_signals(self, day_df, sentiment, **kwargs):
        if len(day_df) < 2: return 'HOLD'
        current, last = day_df.iloc[-1], day_df.iloc[-2]
        cpr_pivots = kwargs.get('cpr_pivots', {})
        
        cpr_signal = check_cpr_breakout(current, cpr_pivots, last)

        if cpr_signal == "Bullish":
            if current['close'] > current['ema_50'] and current['rsi_14'] > 55:
                return 'BUY'
        elif cpr_signal == "Bearish":
            if current['close'] < current['ema_50'] and current['rsi_14'] < 45:
                return 'SELL'
        return 'HOLD'

    def get_status_message(self, day_df, sentiment, **kwargs):
        cpr = kwargs.get('cpr_pivots', {})
        if not cpr: return f"Awaiting signal for {self.name}: CPR pivots not calculated."
        tc, bc = cpr.get('tc', 0), cpr.get('bc', 0)
        return f"Awaiting signal: Bullish breakout above CPR({tc:.2f}) or Bearish breakout below CPR({bc:.2f})."

class Supertrend_MACD_Strategy(BaseStrategy):
    """A trend-following strategy using Supertrend direction and MACD crossover."""
    def __init__(self, kite, config):
        super().__init__(kite, config)
        self.name = "Supertrend_MACD"

    def generate_signals(self, day_df, sentiment, **kwargs):
        if len(day_df) < 2: return 'HOLD'
        current = day_df.iloc[-1]
        
        # Column names from pandas_ta
        st_direction_col = 'SUPERTd_10_3.0'
        macd_col, macd_signal_col = 'MACD_12_26_9', 'MACDs_12_26_9'

        if current[st_direction_col] == 1 and current[macd_col] > current[macd_signal_col]:
            return 'BUY'
        if current[st_direction_col] == -1 and current[macd_col] < current[macd_signal_col]:
            return 'SELL'
        return 'HOLD'

    def get_status_message(self, day_df, sentiment, **kwargs):
        return "Awaiting signal: Supertrend and MACD must align for a trend signal."

# Note: Other strategies would follow a similar, refactored pattern.
# For brevity, only a few are shown with the new, consistent logic.

class EMA_Cross_RSI_Strategy(BaseStrategy):
    """A classic momentum strategy based on a recent EMA crossover confirmed by RSI."""
    def __init__(self, kite, config):
        super().__init__(kite, config)
        self.name = "EMA_Cross_RSI"

    def generate_signals(self, day_df, sentiment, **kwargs):
        lookback = self.config['trading_flags'].get('ema_cross_lookback', 5)
        if len(day_df) < lookback + 1: return 'HOLD'
        
        current = day_df.iloc[-1]

        # Bullish condition check
        if current['ema_9'] > current['ema_15'] and current['rsi_14'] > 55:
            # Check if a crossover happened recently
            recent_slice = day_df.iloc[-lookback:-1]
            if any(recent_slice['ema_9'] < recent_slice['ema_15']):
                return 'BUY'

        # Bearish condition check
        if current['ema_9'] < current['ema_15'] and current['rsi_14'] < 45:
            # Check if a crossover happened recently
            recent_slice = day_df.iloc[-lookback:-1]
            if any(recent_slice['ema_9'] > recent_slice['ema_15']):
                return 'SELL'

        return 'HOLD'

    def get_status_message(self, day_df, sentiment, **kwargs):
        return "Awaiting signal: A recent 9/15 EMA cross confirmed by RSI."


class Reversal_Detector_Strategy(BaseStrategy):
    """A reversal strategy for overextended trends, confirmed by divergence and a structure break."""
    def __init__(self, kite, config):
        super().__init__(kite, config)
        self.name = "Reversal_Detector"
        self.is_reversal_trade = True # This strategy can trade against the main sentiment

    def generate_signals(self, day_df, sentiment, **kwargs):
        if len(day_df) < 45: return 'HOLD' # Needs lookback for divergence
        
        trend_status = is_trend_overextended(day_df)
        if trend_status == "None": return 'HOLD'

        rsi_divergence = check_momentum_divergence(day_df['close'], day_df['rsi_14'])
        current = day_df.iloc[-1]

        if trend_status == "Uptrend" and rsi_divergence == "Bearish" and current['close'] < current['ema_9']:
            logging.info(f"[{self.name}] Bearish Reversal Signal Confirmed.")
            return 'SELL'

        if trend_status == "Downtrend" and rsi_divergence == "Bullish" and current['close'] > current['ema_9']:
            logging.info(f"[{self.name}] Bullish Reversal Signal Confirmed.")
            return 'BUY'
        
        return 'HOLD'

    def get_status_message(self, day_df, sentiment, **kwargs):
        trend_status = is_trend_overextended(day_df)
        if trend_status != "None":
            return f"Awaiting reversal: Overextended {trend_status} detected. Looking for divergence."
        return f"Awaiting signal: Waiting for a sustained, overextended trend to form."


def get_strategy(name: str, kite, config) -> BaseStrategy:
    """Factory function to get a strategy instance by name."""
    strategies = {
        "Gemini_Default": Gemini_Default_Strategy,
        "Supertrend_MACD": Supertrend_MACD_Strategy,
        "EMA_Cross_RSI": EMA_Cross_RSI_Strategy,
        "Reversal_Detector": Reversal_Detector_Strategy,
        # Add other refactored strategy classes here
        # "Volatility_Cluster_Reversal": VolatilityClusterStrategy,
        # "Volume_Spread_Analysis": VSA_Strategy,
        # "Momentum_VWAP_RSI": Momentum_VWAP_RSI_Strategy,
        # "Breakout_Prev_Day_HL": Breakout_Prev_Day_HL_Strategy,
        # "Opening_Range_Breakout": Opening_Range_Breakout_Strategy,
        # "BB_Squeeze_Breakout": Bollinger_Band_Squeeze_Strategy,
        # "MA_Crossover": MA_Crossover_Strategy,
        # "RSI_Divergence": RSI_Divergence_Strategy,
    }
    strategy_class = strategies.get(name)
    if not strategy_class:
        logging.error(f"Strategy '{name}' not found. Defaulting to Gemini_Default.")
        return Gemini_Default_Strategy(kite, config)
    return strategy_class(kite, config)