import pandas as pd
import datetime
import logging
import time
import os
from strategy_factory import get_strategy
from market_context import MarketConditionIdentifier
# ARCHITECTURAL IMPROVEMENT: Use the same indicator calculator as the live bot
from indicator_calculator import calculate_all_indicators
from indicators import calculate_cpr

def fetch_historical_data_in_chunks(kite, token, from_date, to_date, timeframe):
    """
    Fetches historical data by breaking the request into smaller chunks
    to comply with the API's date range limits for intraday data.
    """
    all_data = []
    current_from = from_date

    while current_from <= to_date:
        current_to = min(current_from + datetime.timedelta(days=99), to_date)
        logging.info(f"Fetching data from {current_from} to {current_to}")
        try:
            chunk = kite.historical_data(token, current_from, current_to, timeframe)
            if chunk:
                all_data.extend(chunk)
            time.sleep(0.5) # Respect API rate limits
        except Exception as e:
            logging.error(f"Error fetching data chunk from {current_from} to {current_to}: {e}")

        current_from = current_to + datetime.timedelta(days=1)

    return pd.DataFrame(all_data)

def run_backtest(kite, config, strategy_name, from_date, to_date, target_conditions=None):
    """
    Runs a backtest for a given strategy, ensuring consistency with live trading logic.
    """
    mode = "Conditional" if target_conditions else "Full"
    logging.info(f"--- Starting {mode} Backtest for Strategy: {strategy_name} ---")
    if mode == "Conditional": logging.info(f"--- Target Conditions: {target_conditions} ---")

    underlying_name = config['trading_flags']['underlying_instrument']
    timeframe = config['trading_flags']['chart_timeframe']

    try:
        nifty_token = [i['instrument_token'] for i in kite.instruments('NSE') if i['tradingsymbol'] == underlying_name][0]
        vix_token = [i['instrument_token'] for i in kite.instruments('NSE') if i['tradingsymbol'] == 'INDIA VIX'][0]
    except (IndexError, KeyError) as e:
        logging.error(f"Could not find instrument token: {e}"); return 0.0

    # Fetch all necessary data upfront
    all_data_day = fetch_historical_data_in_chunks(kite, nifty_token, from_date, to_date, "day")
    all_data_tf = fetch_historical_data_in_chunks(kite, nifty_token, from_date, to_date, timeframe)

    if all_data_day.empty or all_data_tf.empty:
        logging.error("Failed to fetch sufficient historical data for backtest."); return 0.0

    all_data_day['date'] = pd.to_datetime(all_data_day['date']).dt.date
    all_data_tf['date_only'] = pd.to_datetime(all_data_tf['date']).dt.date

    strategy = get_strategy(strategy_name, kite, config)
    trades = []
    
    # Pre-filter dates to test if running a conditional backtest
    if target_conditions:
        logging.info("Filtering historical dates based on target conditions...")
        vix_data = fetch_historical_data_in_chunks(kite, vix_token, from_date, to_date, "day")
        if not vix_data.empty:
            vix_data['date'] = pd.to_datetime(vix_data['date']).dt.date
        condition_identifier = MarketConditionIdentifier(kite, config)
        
        historical_dates_to_test = {
            date_obj for date_obj in all_data_day['date'].unique()
            if target_conditions.issubset(condition_identifier.get_conditions_for_date(date_obj, vix_data, all_data_day))
        }
        logging.info(f"Found {len(historical_dates_to_test)} matching historical days.")
        if not historical_dates_to_test:
            logging.warning("No matching historical days found for conditional backtest."); return 0.0
    else:
        historical_dates_to_test = set(all_data_day['date'].unique())


    for i in range(1, len(all_data_day)):
        current_date = all_data_day.iloc[i]['date']
        if current_date not in historical_dates_to_test:
            continue

        logging.info(f"Backtesting for date: {current_date}")
        day_tf_df = all_data_tf[all_data_tf['date_only'] == current_date].copy()
        if len(day_tf_df) < 50: continue

        # --- CENTRALIZED INDICATOR CALCULATION ---
        # This ensures the backtest uses the same logic as the live bot.
        day_tf_df = calculate_all_indicators(day_tf_df, config)
        
        cpr_pivots = calculate_cpr(all_data_day.iloc[i-1:i])
        
        position = None
        entry_price = 0
        for j in range(len(day_tf_df)): # Iterate through each candle of the day
            if not position:
                # Pass index `j` to use the correct historical slice of the dataframe
                signal = strategy.generate_signals(day_tf_df, "Bullish", index=j, cpr_pivots=cpr_pivots) # Assume bullish for backtest simplicity
                if signal == 'BUY':
                    position, entry_price = 'BUY', day_tf_df.iloc[j]['close']
                elif signal == 'SELL':
                    position, entry_price = 'SELL', day_tf_df.iloc[j]['close']
            else:
                # Simple SL/TP logic for backtesting
                current_low = day_tf_df.iloc[j]['low']
                current_high = day_tf_df.iloc[j]['high']
                exit_price = 0

                if position == 'BUY' and (current_low < entry_price * 0.98 or current_high > entry_price * 1.04):
                    exit_price = day_tf_df.iloc[j]['close']
                elif position == 'SELL' and (current_high > entry_price * 1.02 or current_low < entry_price * 0.96):
                    exit_price = day_tf_df.iloc[j]['close']

                if exit_price > 0:
                    trades.append({'entry': entry_price, 'exit': exit_price, 'type': position})
                    position = None # Reset for next trade

    if not trades:
        logging.warning(f"No trades were executed during {mode} backtest for {strategy_name}."); return 0.0

    wins = sum(1 for t in trades if (t['type'] == 'BUY' and t['exit'] > t['entry']) or (t['type'] == 'SELL' and t['exit'] < t['entry']))
    win_rate = (wins / len(trades)) * 100
    logging.info(f"--- {mode} Backtest Results for {strategy_name}: ---")
    logging.info(f"Total Trades: {len(trades)}, Wins: {wins}, Win Rate: {win_rate:.2f}%")

    # Save backtest results to CSV
    result_df = pd.DataFrame({
        'timestamp': [datetime.datetime.now()], 'strategy': [strategy_name], 'mode': [mode],
        'conditions': [str(target_conditions) if target_conditions else 'N/A'],
        'from_date': [from_date], 'to_date': [to_date], 'total_trades': [len(trades)],
        'win_rate_pct': [win_rate]
    })
    log_path = 'output/backtest_results.csv'
    
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    
    result_df.to_csv(log_path, mode='a', header=not os.path.exists(log_path), index=False)
    logging.info(f"Backtest results for {strategy_name} saved to {log_path}")

    return win_rate