import logging
import os
import smtplib
import pandas as pd
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

LOG_FILE = 'output/trade_log.xlsx'
os.makedirs('output', exist_ok=True)

def initialize_trade_log():
    """Creates the trade log Excel file with all necessary columns if it doesn't exist."""
    if not os.path.exists(LOG_FILE) or os.path.getsize(LOG_FILE) == 0:
        all_columns = [
            'Timestamp', 'OrderID', 'Symbol', 'TradeType', 'EntryPrice', 'ExitPrice',
            'Quantity', 'ProfitLoss', 'ProfitLoss_Pct', 'Status', 'Strategy', 'Rationale'
        ]
        pd.DataFrame(columns=all_columns).to_excel(LOG_FILE, index=False)
        logging.info(f"Trade log created at {LOG_FILE}")

def log_trade(trade_details):
    """Appends a single trade record to the Excel log file."""
    try:
        # Calculate P/L percentage based on investment
        entry_price = trade_details.get('EntryPrice', 0)
        quantity = trade_details.get('Quantity', 0)
        if entry_price and quantity:
            investment = entry_price * quantity
            pnl_pct = (trade_details.get('ProfitLoss', 0) / investment) * 100 if investment != 0 else 0
            trade_details['ProfitLoss_Pct'] = round(pnl_pct, 2)
        else:
            trade_details['ProfitLoss_Pct'] = 0.0

        all_columns = ['Timestamp', 'OrderID', 'Symbol', 'TradeType', 'EntryPrice', 'ExitPrice', 'Quantity', 'ProfitLoss', 'ProfitLoss_Pct', 'Status', 'Strategy', 'Rationale']
        
        # Ensure all keys exist to prevent errors
        for col in all_columns:
            trade_details.setdefault(col, None)

        # Read existing log or create a new DataFrame
        try:
            df = pd.read_excel(LOG_FILE)
        except (FileNotFoundError, ValueError): # Handles empty or new file
            df = pd.DataFrame(columns=all_columns)

        new_trade_df = pd.DataFrame([trade_details])
        df = pd.concat([df, new_trade_df], ignore_index=True)
        df.to_excel(LOG_FILE, index=False)
        logging.info(f"Successfully logged trade for {trade_details.get('Symbol', 'N/A')}")
    except Exception as e:
        logging.error(f"Failed to log trade to Excel: {e}", exc_info=True)


def send_daily_report(config, date_str, starting_capital=0, no_trades_reason=None):
    """
    Reads the trade log and sends a daily report with segregated live and paper trade stats.
    FIX: Now accepts 'starting_capital' to calculate daily P/L %.
    """
    email_conf = config.get('email_settings', {})
    if not email_conf.get('send_daily_report', False):
        logging.info("Email reporting is disabled."); return

    try:
        today = pd.to_datetime(date_str).date()
        df = pd.read_excel(LOG_FILE) if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 0 else pd.DataFrame()

        if not df.empty and 'Timestamp' in df.columns:
            df['Timestamp'] = pd.to_datetime(df['Timestamp'])

        daily_html, live_pnl, paper_pnl = generate_daily_summary(df, today, starting_capital, no_trades_reason)

        subject_parts = [f"Trading Report for {today.strftime('%d %b, %Y')}"]
        if live_pnl is not None: subject_parts.append(f"Live P/L: ₹{live_pnl:,.2f}")
        if paper_pnl is not None: subject_parts.append(f"Paper P/L: ₹{paper_pnl:,.2f}")
        if no_trades_reason: subject_parts.append("No Trades")
        subject = " | ".join(subject_parts)

        msg = MIMEMultipart()
        msg['From'] = email_conf['sender_email']
        msg['To'] = email_conf['receiver_email']
        msg['Subject'] = subject
        msg.attach(MIMEText(daily_html, 'html'))

        with smtplib.SMTP(email_conf['smtp_server'], email_conf['smtp_port']) as server:
            server.starttls()
            server.login(email_conf['sender_email'], email_conf['sender_password'])
            server.send_message(msg)
        logging.info("Successfully sent daily email report.")
    except Exception as e:
        logging.error(f"Failed to send email report: {e}", exc_info=True)

def _generate_summary_table(df, title, capital):
    """Helper function to generate an HTML summary table for a given dataframe."""
    if df.empty:
        return f"<h3>{title}</h3><p>No trades were executed in this mode today.</p>", None

    total_pnl = df['ProfitLoss'].sum()
    wins = (df['ProfitLoss'] > 0).sum()
    losses = len(df) - wins
    win_rate = (wins / len(df) * 100) if len(df) > 0 else 0
    
    # ENHANCEMENT: Calculate and display Net P/L % if capital is provided
    pnl_percent_str = ""
    if capital > 0:
        pnl_percent = (total_pnl / capital) * 100
        pnl_percent_str = f"""
        <tr><td><strong>Net P/L % of Capital</strong></td><td><strong>{pnl_percent:.2f}%</strong></td></tr>
        """

    summary_html = f"""
    <h3>{title}</h3>
    <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 400px;">
        <tr><td>Winning Trades</td><td>{wins}</td></tr>
        <tr><td>Losing Trades</td><td>{losses}</td></tr>
        <tr><td>Win Rate</td><td>{win_rate:.2f}%</td></tr>
        <tr><td><strong>Total P/L</strong></td><td><strong>₹{total_pnl:,.2f}</strong></td></tr>
        {pnl_percent_str}
    </table>
    """

    df_display = df[['Timestamp', 'OrderID', 'Symbol', 'TradeType', 'EntryPrice', 'ExitPrice', 'Quantity', 'ProfitLoss', 'Strategy', 'Rationale']].copy()
    for col in ['ProfitLoss', 'EntryPrice', 'ExitPrice']:
        if col in df_display.columns:
            df_display[col] = df_display[col].apply(lambda x: f'₹{x:,.2f}' if pd.notna(x) else 'N/A')
    
    df_display.fillna('', inplace=True)
    trades_html = df_display.to_html(index=False, border=1)

    return f"{summary_html}<h4>Trade Details:</h4>{trades_html}", total_pnl

def generate_daily_summary(df, date_obj, capital, reason):
    """Generates the HTML summary for a single day, segregating live and paper trades."""
    html_style = "<style>body{font-family:Arial,sans-serif;margin:20px;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #ddd;padding:8px;text-align:left;} th{background-color:#f2f2f2;}</style>"
    header = f"<h2>Daily Summary: {date_obj.strftime('%d %b, %Y')}</h2>"

    if reason:
        body = f"{header}<p><strong>No trades were placed today. Reason:</strong> {reason}</p>"
        return f"<html><head>{html_style}</head><body>{body}</body></html>", None, None

    if df.empty or 'Timestamp' not in df.columns:
        body = f"{header}<p>No trades found in log file.</p>"
        return f"<html><head>{html_style}</head><body>{body}</body></html>", None, None

    daily_trades = df[df['Timestamp'].dt.date == date_obj].copy()
    if daily_trades.empty:
        body = f"{header}<p>No trades were executed today.</p>"
        return f"<html><head>{html_style}</head><body>{body}</body></html>", None, None

    # Segregate trades based on OrderID
    daily_trades['IsPaper'] = daily_trades['OrderID'].astype(str).str.startswith('PAPER_')
    live_trades = daily_trades[~daily_trades['IsPaper']].copy()
    paper_trades = daily_trades[daily_trades['IsPaper']].copy()

    live_html, live_pnl = _generate_summary_table(live_trades, "Live Trades Summary", capital)
    paper_html, paper_pnl = _generate_summary_table(paper_trades, "Paper Trades Summary", 0) # Paper capital is not tracked

    full_html_body = f"{header}{live_html}<hr>{paper_html}"
    return f"<html><head>{html_style}</head><body>{full_html_body}</body></html>", live_pnl, paper_pnl

def send_monthly_report(config, date_str):
    """Generates and sends a summary report for the entire month's performance."""
    # This function remains largely the same, but can be enhanced similarly if needed.
    email_conf = config.get('email_settings', {})
    if not email_conf.get('send_daily_report', False): return
    logging.info("Generating monthly report...")
    today = pd.to_datetime(date_str).date()
    
    try:
        df = pd.read_excel(LOG_FILE) if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 0 else pd.DataFrame()
        if df.empty:
            body = f"<p>No trades were executed during {today.strftime('%B %Y')}.</p>"
        else:
            df['Timestamp'] = pd.to_datetime(df['Timestamp'])
            monthly_trades = df[(df['Timestamp'].dt.year == today.year) & (df['Timestamp'].dt.month == today.month)]
            # Segregate monthly trades
            monthly_trades['IsPaper'] = monthly_trades['OrderID'].astype(str).str.startswith('PAPER_')
            live_trades_monthly = monthly_trades[~monthly_trades['IsPaper']]
            
            if live_trades_monthly.empty:
                body = f"<p>No live trades were executed during {today.strftime('%B %Y')}.</p>"
            else:
                total_pnl = live_trades_monthly['ProfitLoss'].sum()
                wins = (live_trades_monthly['ProfitLoss'] > 0).sum()
                losses = len(live_trades_monthly) - wins
                win_rate = (wins / len(live_trades_monthly) * 100) if len(live_trades_monthly) > 0 else 0
                body = f"""
                <h3>Monthly Live Performance Summary for {today.strftime('%B %Y')}</h3>
                <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 400px;">
                    <tr><td>Total P/L</td><td>₹{total_pnl:,.2f}</td></tr>
                    <tr><td>Winning Trades</td><td>{wins}</td></tr>
                    <tr><td>Losing Trades</td><td>{losses}</td></tr>
                    <tr><td><strong>Monthly Win Rate</strong></td><td><strong>{win_rate:.2f}%</strong></td></tr>
                </table><hr>
                """
        
        subject = f"Monthly Trading Summary: {today.strftime('%B %Y')}"
        msg = MIMEMultipart(); msg['From'], msg['To'], msg['Subject'] = email_conf['sender_email'], email_conf['receiver_email'], subject
        msg.attach(MIMEText(f"<html><body>{body}</body></html>", 'html'))
        
        with smtplib.SMTP(email_conf['smtp_server'], email_conf['smtp_port']) as server:
            server.starttls(); server.login(email_conf['sender_email'], email_conf['sender_password'])
            server.send_message(msg)
        logging.info("Successfully sent monthly report.")
    except Exception as e:
        logging.error(f"Failed to send monthly report: {e}", exc_info=True)