import logging
import datetime
import json
import os
import time
from newsapi import NewsApiClient
from textblob import TextBlob

class SentimentAgent:
    """
    An agent for fetching news and determining market sentiment with intensity.
    Includes a time-based local cache to avoid redundant API calls.
    """
    def __init__(self, config):
        self.config = config
        self.newsapi = NewsApiClient(api_key=config['news_api']['api_key'])
        self.cache_dir = "output/news_cache"
        os.makedirs(self.cache_dir, exist_ok=True)
        # A broader and more relevant list of keywords for the Indian market context
        self.search_keywords = [
            "Reliance Industries", "HDFC Bank", "ICICI Bank", "Infosys",
            "Larsen & Toubro", "TCS", "Bharti Airtel", "State Bank of India", "ITC",
            "RBI", "NIFTY 50", "Sensex", "Indian economy", "SEBI", "monetary policy",
            "inflation India", "GDP India"
        ]

    def _get_news_articles(self):
        """
        Fetches news from the last 2 days. It serves from a time-sensitive
        cache to allow for periodic refreshes of news within the same day.
        """
        today = datetime.date.today()
        cache_file_path = os.path.join(self.cache_dir, f"news_{today.isoformat()}.json")
        cache_expiration_seconds = 3600  # Cache is valid for 1 hour

        # Check if a recent cache file exists and is not expired
        if os.path.exists(cache_file_path) and (time.time() - os.path.getmtime(cache_file_path)) < cache_expiration_seconds:
            logging.info(f"SentimentAgent: Loading news from recent cache (less than {int(cache_expiration_seconds / 60)} mins old).")
            try:
                with open(cache_file_path, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                logging.warning("SentimentAgent: Cache file is corrupted or missing. Fetching fresh news.")

        logging.info("SentimentAgent: Fetching fresh news from API...")
        try:
            # Construct a more effective query
            query = " OR ".join(f'"{k}"' for k in self.search_keywords)
            from_date = today - datetime.timedelta(days=2)

            top_headlines = self.newsapi.get_everything(
                q=query,
                language='en',
                sort_by='publishedAt',  # Newest articles first
                page_size=100,
                from_param=from_date.isoformat()
            )

            with open(cache_file_path, 'w') as f:
                json.dump(top_headlines, f)
            return top_headlines
        except Exception as e:
            # Catching potential NewsAPI exceptions
            logging.error(f"SentimentAgent: Could not fetch news from API: {e}")
            return None

    def get_market_sentiment(self) -> str:
        """
        Calculates sentiment using a weighted average based on news recency
        and returns bias with intensity (e.g., "Very Bullish", "Neutral").
        """
        news_data = self._get_news_articles()
        if not news_data or not news_data.get('articles'):
            logging.warning("SentimentAgent: No news articles found. Defaulting to Neutral.")
            return "Neutral"

        sentiment_scores = []
        articles = news_data['articles']
        for article in articles:
            # Ensure title and description are valid strings
            title = article.get('title', '')
            description = article.get('description', '')
            if title and title != "[Removed]":
                content = f"{title}. {description or ''}"
                polarity = TextBlob(content).sentiment.polarity
                sentiment_scores.append(polarity)

        if not sentiment_scores:
            logging.warning("SentimentAgent: No valid headlines could be analyzed. Defaulting to Neutral.")
            return "Neutral"

        # --- Weighted Average Calculation ---
        # Articles are already sorted newest to oldest from the API.
        # This gives more weight to the most recent news.
        weighted_sum = 0
        total_weight = 0
        n = len(sentiment_scores)
        for i, score in enumerate(sentiment_scores):
            weight = n - i  # Linear decay weight
            weighted_sum += score * weight
            total_weight += weight

        avg_sentiment = weighted_sum / total_weight if total_weight > 0 else 0.0

        logging.info(f"SentimentAgent: Calculated weighted average sentiment score: {avg_sentiment:.3f} from {n} articles.")

        # Define clear thresholds for sentiment intensity
        if avg_sentiment > 0.25: return "Very Bullish"
        if avg_sentiment > 0.05: return "Bullish"
        if avg_sentiment < -0.25: return "Very Bearish"
        if avg_sentiment < -0.05: return "Bearish"
        return "Neutral"